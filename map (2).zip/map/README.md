# covid19-world-stats-js

Website showing confirmed cases, active cases, recovered cases and deaths in all over world due to pandemic.

<img src="https://user-images.githubusercontent.com/47572837/83791618-9bb86380-a6b7-11ea-98ff-4fe4df205cee.png" width="90%"></img> 

<img src="https://user-images.githubusercontent.com/47572837/83792190-52b4df00-a6b8-11ea-91bb-90beda73227f.png" width="30%"></img>  <img src="https://user-images.githubusercontent.com/47572837/83792195-53e60c00-a6b8-11ea-9fc6-11aefe69edf4.png" width="30%"></img>  <img src="https://user-images.githubusercontent.com/47572837/83792197-547ea280-a6b8-11ea-9cea-35f657d48be5.png" width="30%"></img> 
